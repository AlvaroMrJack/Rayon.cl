<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coming_soon extends CI_Controller {

	public function index()
	{
		$this->load->view('proximamente/proximamente');
	}

}

/* End of file Coming_soon.php */
/* Location: ./application/controllers/Coming_soon.php */